# GPA Calculator

This program will calculate GPA. This is just a simple program made to test making a pip package.